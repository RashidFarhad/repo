export LANG="en_US.UTF-8"
